import { titleLoginSelector, usernameLoginSelector, passwordLoginSelector } from '../../support/commands';

describe('home page', () => {
  before(() => {
    cy.window().then(win => {
      win.sessionStorage.clear();
    });

    cy.clearCookies();
    cy.visit('');
  });

  beforeEach(() => {});

  it('greets with signin', () => {
    cy.get(titleLoginSelector).should('be.visible');
  });

  it('requires username', () => {
    cy.get(passwordLoginSelector).type('a-password');
    cy.get(passwordLoginSelector).should('be.visible');
    cy.get(passwordLoginSelector).clear();
  });

  it('requires password', () => {
    cy.get(usernameLoginSelector).type('a-login');
    cy.get(usernameLoginSelector).should('be.visible');
    cy.get(usernameLoginSelector).clear();
  });
});
