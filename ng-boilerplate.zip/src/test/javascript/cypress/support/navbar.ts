/* eslint-disable @typescript-eslint/no-namespace */
/* eslint-disable @typescript-eslint/no-use-before-define */

import { navbarSelector } from './commands';

Cypress.Commands.add('clickOnAdminMenuItem', (item: string) => {
  return cy.get(navbarSelector).click({ force: true }).get(`.dropdown-item[href="/admin/${item}"]`).click({ force: true });
});

Cypress.Commands.add('clickOnEntityMenuItem', (entityName: string) => {
  return cy.get(navbarSelector).click({ force: true }).get(`.dropdown-item[href="/${entityName}"]`).click({ force: true });
});

declare global {
  namespace Cypress {
    interface Chainable<Subject> {
      clickOnLoginItem(): Cypress.Chainable;
    }
  }
}

// Convert this to a module instead of script (allows import/export)
export {};
