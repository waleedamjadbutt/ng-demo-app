import { Component } from '@angular/core';

@Component({
  selector: 'fc-footer',
  templateUrl: './footer.component.html',
})
export class FooterComponent {}
