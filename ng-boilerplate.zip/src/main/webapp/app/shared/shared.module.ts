import { NgModule } from '@angular/core';
import { SharedLibsModule } from './shared-libs.module';
import { AngularMaterialModule } from './angular-material.module';
import { FindLanguageFromKeyPipe } from './language/find-language-from-key.pipe';
import { TranslateDirective } from './language/translate.directive';
import { AlertComponent } from './alert/alert.component';
import { AlertErrorComponent } from './alert/alert-error.component';
import { SortDirective } from './directives/sort.directive';

@NgModule({
  imports: [SharedLibsModule, AngularMaterialModule],
  declarations: [FindLanguageFromKeyPipe, TranslateDirective, AlertComponent, AlertErrorComponent, SortDirective],
  exports: [
    SharedLibsModule,
    AngularMaterialModule,
    FindLanguageFromKeyPipe,
    TranslateDirective,
    AlertComponent,
    AlertErrorComponent,
    SortDirective,
  ],
})
export class SharedModule {}
