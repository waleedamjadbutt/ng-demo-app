import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

@NgModule({
  imports: [
    RouterModule.forChild([
      /* cibc-needle-add-entity-route - CIBC will add entity modules routes here */
    ]),
  ],
})
export class EntityRoutingModule {}
